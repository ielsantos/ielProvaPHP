<!DOCTYPE html>
<html>
<head>
	<title>ISRAEL PROVA</title>
</head>
<body>
<form action="inserir.php" method="POST">
	<div class="container">
	<div>
		<label> Titulo</label>
		<input type="text" name="title" placeholder="digite seu Titulo">
	</div>
	
	<div>
		<label>Descrição</label>
<textarea name="description" id="" cols="30" rows="10"></textarea>

	</div>
	<div>
		<input type="submit" value="Enviar">
	</div>
		</div>

	
</form>

</body>
</html>